const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').resolve(process.env.APP_HTML || 'android/app/src/main/assets/index.html'),'utf8');
let clock=0,tid=0;const timers=new Map(),nodes=new Map();
function element(id){if(!nodes.has(id)){let markup='';nodes.set(id,{id,hidden:false,disabled:false,dataset:{},style:{setProperty(){}},classList:{add(){},remove(){},toggle(){},replace(){},contains(){return false}},get innerHTML(){return markup},set innerHTML(v){markup=v;if(id==='app'){for(const t of v.matchAll(/<[^>]+id="([^"]+)"[^>]*>/g)){let n=element(t[1]);n.hidden=/\bhidden\b/.test(t[0]);n.disabled=/\bdisabled\b/.test(t[0])}}},textContent:'',insertAdjacentHTML(_,s){this.innerHTML+=s},remove(){},setAttribute(){},removeAttribute(){},cloneNode(){return element('clone')},animate(){return {finished:Promise.resolve()}},getAnimations(){return []},getBoundingClientRect(){return {left:0,top:0,width:100,height:100}},querySelector(){return element('inner')},appendChild(){},getContext(){return new Proxy({},{get(){return ()=>{}}})}})}return nodes.get(id)}
const synth={getVoices(){return [{name:'Korean',lang:'ko-KR'}]},cancel(){},resume(){},speak(u){synth.last=u}};
const context={document:{body:element('body'),hidden:false,getElementById:element,querySelector(s){return element(s)},querySelectorAll(s){return s==='.object-choice'?[element('answer-0'),element('answer-1')]:[]},addEventListener(){},createElement:element},window:{addEventListener(){},speechSynthesis:synth},speechSynthesis:synth,SpeechSynthesisUtterance:function(t){this.text=t},setTimeout(f,d=0){timers.set(++tid,{f,time:clock+d});return tid},clearTimeout(id){timers.delete(id)},setInterval(){return 0},clearInterval(){},localStorage:{getItem(){return null},setItem(){}},navigator:{},location:{protocol:'https:'},matchMedia(){return {matches:false}},console,requestAnimationFrame(){},Blob,URL};
vm.createContext(context);for(const m of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],context);
const run=s=>vm.runInContext(s,context);const flush=async()=>{await Promise.resolve();await Promise.resolve()};
async function advance(ms){clock+=ms;for(const [id,t]of [...timers])if(t.time<=clock){timers.delete(id);t.f()}await flush()}
(async()=>{
for(const [n,s]of [[1,'일'],[7,'칠'],[9,'구'],[10,'십'],[11,'십일'],[20,'이십'],[70,'칠십'],[99,'구십구'],[100,'백']])assert.equal(run(`koSino(${n})`),s);
run("started=true;prefs.voice=true;startQuiz('number',0)");assert.equal(run('state.phase'),'intro');await run('answer(0)');assert.equal(run('state.score'),0);assert.equal(element('choice-area').hidden,true);await advance(1799);assert.equal(run('state.phase'),'intro');await advance(1);assert.equal(run('state.phase'),'speaking');assert.equal(element('choice-area').hidden,true);synth.last.onend();await flush();assert.equal(run('state.phase'),'answer');assert.equal(element('choice-area').hidden,false);
run("startQuiz('number',0)");await advance(1800);run('home()');synth.last.onend();await flush();assert.equal(run('state.view'),'home');
run('prefs.voice=false');
for(const mode of ['number','count','english','consonant','vowel','alphabetUpper','alphabetLower']){run(`startQuiz('${mode}',0)`);for(let q=0;q<10;q++){assert.equal(run('/[0-9]/.test(questionCopy())'),false);await advance(1800);const c=run('state.options.indexOf(targetLabel())');await run(`answer(${1-c})`);await run(`answer(${c})`);await run(`answer(${c})`);run('nextQuestion()')}assert.equal(run('state.score'),80);assert.equal(run('state.view'),'result')}
run("startQuiz('number',9)");assert.equal(run('state.lessonKinds.includes("floor")&&state.lessonKinds.includes("bus")&&state.lessonKinds.includes("quantity")'),true);assert.equal(run('pickCreature(100)!==undefined'),true);
for(const score of [0,100]){run("startQuiz('number',0)");for(let q=0;q<10;q++){await advance(1800);const c=run('state.options.indexOf(targetLabel())');if(!score){await run(`answer(${1-c})`);await run(`answer(${1-c})`)}else await run(`answer(${c})`);run('nextQuestion()')}assert.equal(run('state.score'),score)}
for(let range=0;range<10;range++){
run(`startSequence(${range})`);const deck=Array.from(run('state.deck'));
assert.equal(new Set(deck).size,10);assert.notDeepEqual(deck,deck.slice().sort((a,b)=>a-b));
await run(`fill(${range*10+2})`);assert.equal(run('state.filled'),0);
for(let n=range*10+1;n<=range*10+10;n++){await run(`fill(${n})`);await run(`fill(${n})`)}
assert.equal(run('state.filled'),10);assert.equal(run('state.next'),range*10+11);
}
run('startSequence(1); fill(11); fill(12); fill(11)');await flush();assert.equal(run('state.filled'),1);
run('startSequence(1); fill(11); home()');await flush();assert.equal(run('state.view'),'home');
const themeIds=new Set();for(let i=0;i<100;i++){const prev=run('lastSequenceTheme');run('startSequence(1)');const now=run('lastSequenceTheme');assert.notEqual(prev,now);themeIds.add(now)}assert.equal(themeIds.size,10);
console.log('PASS: seven quiz modes scoring; narration gating; 10 sequence ranges with shuffled unique cards; wrong and repeated taps; flight completion; stale navigation; 10 themes without immediate repeats. Mock DOM, not device rendering.');
})().catch(e=>{console.error(e);process.exit(1)});
